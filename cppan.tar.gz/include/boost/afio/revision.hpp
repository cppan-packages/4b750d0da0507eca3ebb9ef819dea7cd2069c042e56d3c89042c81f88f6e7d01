// Note the second line of this file must ALWAYS be the git SHA, third line ALWAYS the git SHA update time
#define BOOST_AFIO_PREVIOUS_COMMIT_REF    416b2f40487201215e431198cfa41edd52fb1f29
#define BOOST_AFIO_PREVIOUS_COMMIT_DATE   "2016-07-20 12:17:26 +00:00"
#define BOOST_AFIO_PREVIOUS_COMMIT_UNIQUE 416b2f40
